/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tokospatu;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author LENOVO
 */
public class mainpage extends javax.swing.JFrame {

    
    Connection conn;
    private String inputUsername;
    public mainpage() {
        initComponents();
        conn = koneksi.getConnection();
        loadCardsVerticalCategory();
    }
    
    
    private void loadCardsVerticalCategory() {

        try {
            File fontStyleM1 = new File("src/Poppins/Poppins-Light.ttf");
            Font fontm24 = Font.createFont(Font.TRUETYPE_FONT, fontStyleM1).deriveFont(12f);
            
            File fontStyleR = new File("src/Poppins/Poppins-ExtraLight.ttf");
            Font fontr14 = Font.createFont(Font.TRUETYPE_FONT, fontStyleR).deriveFont(8f);
            
            String sql2 = "SELECT namaSepatu, jenisSepatu, hargaSepatu, gambarSepatu, deskripsiSepatu FROM stock ORDER BY RAND()";
            
            java.sql.Connection conn = (Connection) koneksi.getConnection();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql2);
            
            while (res.next()) {
            String namaSepatu = res.getString("namaSepatu");
            String jenisSepatu = res.getString("jenisSepatu");
            String hargaSepatu = res.getString("hargaSepatu");
            byte[] imgBytes = res.getBytes("gambarSepatu");

            JPanel card = new JPanel();
            card.setBackground(Color.decode("#ffffff"));
            card.setPreferredSize(new Dimension(150, 200));
            card.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
            card.putClientProperty(FlatClientProperties.STYLE, "arc: 16");

            JPanel pic = new JPanel();
            pic.setBackground(Color.red);
            pic.setPreferredSize(new Dimension(100, 100));
            pic.setLayout(new BoxLayout(pic, BoxLayout.Y_AXIS));
            pic.putClientProperty(FlatClientProperties.STYLE, "arc: 16");

            JLabel labelGambar = new JLabel();
            ImageIcon icon = new ImageIcon(imgBytes);
            Image scaledImage = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            labelGambar.setIcon(new ImageIcon(scaledImage));
            pic.add(labelGambar);

            JPanel content = new JPanel();
            content.setBackground(Color.white);
            content.setPreferredSize(new Dimension(120, 100));
            content.setLayout(new GridLayout(0, 1));

            JPanel contentBox1 = new JPanel();
            contentBox1.setBackground(Color.white);
            contentBox1.setPreferredSize(new Dimension(20, 20));
            contentBox1.setLayout(new BoxLayout(contentBox1, BoxLayout.Y_AXIS));
            content.add(contentBox1);

            JLabel labelJudul = new JLabel(namaSepatu, SwingConstants.LEFT);
            labelJudul.setFont(fontm24);
            contentBox1.add(labelJudul);

            JLabel labeljenis = new JLabel(jenisSepatu, SwingConstants.LEFT);
            labeljenis.setFont(fontr14);
            contentBox1.add(labeljenis);

            JLabel labelharga = new JLabel("Rp " + hargaSepatu, SwingConstants.LEFT);
            labelharga.setFont(fontr14);
            contentBox1.add(labelharga);

            JButton tombolbeli = new JButton("Buy");
            tombolbeli.setBackground(Color.decode("#ff8040"));
            tombolbeli.setForeground(Color.white);
            tombolbeli.setPreferredSize(new Dimension(80, 20));

            tombolbeli.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        transaksi transaksiFrame = new transaksi();
                        transaksiFrame.setsepatu(namaSepatu);
                        transaksiFrame.setcust(inputUsername);
                        transaksiFrame.setVisible(true);
                        dispose();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                    }
                }
            });

            contentBox1.add(tombolbeli);
            card.add(pic);
            card.add(content);

            container.add(card);
        }

        container.revalidate();
        container.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            System.out.println("Error: " + e.getMessage());
        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    public void setUsername(String inputUsername) {
    this.inputUsername = inputUsername;
    profile();
}

public void profile() {
    lbnama.setText("Hello " + inputUsername + "!");
    try {
        String username = inputUsername;
        String userQuery = "SELECT * FROM customers WHERE namacust = ?";
        PreparedStatement psUser = conn.prepareStatement(userQuery);
        psUser.setString(1, username);
        ResultSet rsUser = psUser.executeQuery();
                while (rsUser.next()) {
                    String email = rsUser.getString("emailcust");
                    String alamat = rsUser.getString("alamatcust");
                    byte[] imgBytes = rsUser.getBytes("gambarcust");
                    ImageIcon icon = new ImageIcon(imgBytes);
                    Image scaledImage = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    lbgambar.setIcon(new ImageIcon(scaledImage));
                    SwingUtilities.invokeLater(() -> {
                    lbemail.setText(email);
                    lbalamat.setText(alamat);
                });

                }
            
        
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        homepan = new javax.swing.JPanel();
        panscroll = new javax.swing.JScrollPane();
        container = new javax.swing.JPanel();
        profilpan = new javax.swing.JPanel();
        lbnama = new javax.swing.JLabel();
        lbemail = new javax.swing.JLabel();
        lbalamat = new javax.swing.JLabel();
        lbganti = new javax.swing.JLabel();
        lbgambar = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Poppins Light", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Profile");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Poppins Light", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Home");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("HelveticaNowText Black", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("JayShoes");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel3)
                .addGap(168, 168, 168)
                .addComponent(jLabel2)
                .addGap(29, 29, 29)
                .addComponent(jLabel1))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel1))
                .addGap(17, 17, 17))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 60));

        jPanel2.setBackground(new java.awt.Color(255, 0, 204));
        jPanel2.setLayout(new java.awt.CardLayout());

        panscroll.setBackground(new java.awt.Color(51, 51, 51));

        container.setBackground(new java.awt.Color(51, 51, 51));
        container.setLayout(new java.awt.GridLayout(0, 4, 1, 1));
        panscroll.setViewportView(container);

        javax.swing.GroupLayout homepanLayout = new javax.swing.GroupLayout(homepan);
        homepan.setLayout(homepanLayout);
        homepanLayout.setHorizontalGroup(
            homepanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homepanLayout.createSequentialGroup()
                .addComponent(panscroll, javax.swing.GroupLayout.DEFAULT_SIZE, 724, Short.MAX_VALUE)
                .addContainerGap())
        );
        homepanLayout.setVerticalGroup(
            homepanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panscroll)
        );

        jPanel2.add(homepan, "card3");

        profilpan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbnama.setFont(new java.awt.Font("Poppins Black", 0, 14)); // NOI18N
        lbnama.setText("ad");
        profilpan.add(lbnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 207, 24));

        lbemail.setFont(new java.awt.Font("Poppins ExtraLight", 0, 12)); // NOI18N
        lbemail.setText("jLabel3");
        profilpan.add(lbemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        lbalamat.setFont(new java.awt.Font("Poppins ExtraLight", 0, 12)); // NOI18N
        lbalamat.setText("Address");
        profilpan.add(lbalamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 590, 20));

        lbganti.setFont(new java.awt.Font("Poppins ExtraLight", 0, 12)); // NOI18N
        lbganti.setForeground(new java.awt.Color(0, 153, 0));
        lbganti.setText("Change here.");
        lbganti.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbgantiMouseClicked(evt);
            }
        });
        profilpan.add(lbganti, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 200, -1, -1));

        lbgambar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        profilpan.add(lbgambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 90, 90));

        jLabel6.setFont(new java.awt.Font("Poppins ExtraLight", 0, 12)); // NOI18N
        jLabel6.setText("Address :");
        profilpan.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins ExtraLight", 0, 12)); // NOI18N
        jLabel7.setText("Want to Update your information?");
        profilpan.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        jPanel2.add(profilpan, "card2");

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 730, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        profilpan.setVisible(true);
        homepan.setVisible(false);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        homepan.setVisible(true);
        profilpan.setVisible(false);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void lbgantiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbgantiMouseClicked
        // TODO add your handling code here:
        userupdate userupdateFrame =  new userupdate();
        userupdateFrame.setUserdata(inputUsername);
        userupdateFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lbgantiMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            UIManager.setLookAndFeel(new FlatLightLaf()); // You can also use FlatDarkLaf or other themes
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel container;
    private javax.swing.JPanel homepan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbalamat;
    private javax.swing.JLabel lbemail;
    private javax.swing.JLabel lbgambar;
    private javax.swing.JLabel lbganti;
    private javax.swing.JLabel lbnama;
    private javax.swing.JScrollPane panscroll;
    private javax.swing.JPanel profilpan;
    // End of variables declaration//GEN-END:variables
}
