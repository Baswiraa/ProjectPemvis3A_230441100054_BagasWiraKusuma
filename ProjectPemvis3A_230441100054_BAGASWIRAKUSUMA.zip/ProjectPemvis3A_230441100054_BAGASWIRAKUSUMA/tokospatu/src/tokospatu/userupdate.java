/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tokospatu;

import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Image;
import java.io.File;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author LENOVO
 */
public class userupdate extends javax.swing.JFrame {

    /**
     * Creates new form userupdate
     */
    Connection conn;
    private byte[] gambarBytes = null; 
    private String name;
    public userupdate() {
        initComponents();
        conn = (Connection) koneksi.getConnection();
    }
    
    public void setUserdata(String inputUsername) {
    this.name = inputUsername;
    loaduser();
    
    }
    
    public void loaduser(){
    try {
        String username = name;
        String userQuery = "SELECT * FROM customers WHERE namacust = ?";
        PreparedStatement psUser = conn.prepareStatement(userQuery);
        psUser.setString(1, username);
        ResultSet rsUser = psUser.executeQuery();
                while (rsUser.next()) {
                    String email = rsUser.getString("emailcust");
                    String alamat = rsUser.getString("alamatcust");
                    String pass = rsUser.getString("passcust");
                    byte[] imgBytes = rsUser.getBytes("gambarcust");
                    ImageIcon icon = new ImageIcon(imgBytes);
                    Image scaledImage = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    lbimage.setIcon(new ImageIcon(scaledImage));
                    SwingUtilities.invokeLater(() -> {
                    tfnama.setText(username);
                    tfemail.setText(email);
                    tfpass.setText(pass);
                    tfaddress.setText(alamat);
                });

                }
            
        
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
    }
    
    private void inputImage(){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE","JPG","gif","png");
        fileChooser.addChoosableFileFilter(filter);
        int result = fileChooser.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            imgpath.setText(path);

            try {
                gambarBytes = Files.readAllBytes(selectedFile.toPath());
                ImageIcon imageIcon = new ImageIcon(gambarBytes);

                int labelWidth = 200;
                int labelHeight =200;

                int imageWidth = imageIcon.getIconWidth();
                int imageHeight = imageIcon.getIconHeight();

                double scaleX = (double) labelWidth / (double) imageWidth;
                double scaleY = (double) labelHeight / (double) imageHeight;
                double scale = Math.min(scaleX,scaleY);

                Image scaledImage = imageIcon.getImage().getScaledInstance((int) (scale * imageWidth), (int) (scale * imageHeight), Image.SCALE_SMOOTH);

                lbimage.setIcon(new ImageIcon(scaledImage));
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());
            }
        }
    }
    
   private void edit() {
    try {
        String sql;
        PreparedStatement ps;

        if (gambarBytes != null) {
            sql = "UPDATE customers SET namacust = ?, gambarcust = ?, passcust = ?, alamatcust = ? WHERE emailcust = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1, tfnama.getText());
            ps.setBytes(2, gambarBytes);
            ps.setString(3, tfpass.getText());
            ps.setString(4, tfaddress.getText());
            ps.setString(5, tfemail.getText());
        } else {
            sql = "UPDATE customers SET namacust = ?, passcust = ?, alamatcust = ? WHERE emailcust = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, tfnama.getText());
            ps.setString(2, tfpass.getText()); 
            ps.setString(3, tfaddress.getText()); 
            ps.setString(4, tfemail.getText()); 
        }

        int rowsAffected = ps.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Data updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "No data was updated. Check the email.", "Warning", JOptionPane.WARNING_MESSAGE);
        }

    } catch (SQLException e) {
        // Handle SQL errors and display a message
        JOptionPane.showMessageDialog(this, "Error updating data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnsignup = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        tfnama = new javax.swing.JTextField();
        tfemail = new javax.swing.JTextField();
        tfpass = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        signin = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        imgpath = new javax.swing.JTextField();
        btnpilih = new javax.swing.JButton();
        lbimage = new javax.swing.JLabel();
        tfaddress = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel1.setText("Address");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, -1, -1));

        jLabel2.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel2.setText("Image");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, -1, -1));

        btnsignup.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        btnsignup.setText("Save");
        btnsignup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsignupActionPerformed(evt);
            }
        });
        jPanel1.add(btnsignup, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 290, -1, -1));

        jLabel4.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel4.setText("Email");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 120, -1, -1));
        jPanel1.add(tfnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 190, -1));

        tfemail.setEditable(false);
        jPanel1.add(tfemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 190, -1));
        jPanel1.add(tfpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 190, -1));

        jLabel5.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel5.setText("Password");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, -1, -1));

        jLabel6.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel6.setText("Changed Mind?");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 320, -1, -1));

        signin.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        signin.setForeground(new java.awt.Color(0, 204, 0));
        signin.setText("Back");
        signin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signinMouseClicked(evt);
            }
        });
        jPanel1.add(signin, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 320, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel7.setText("Username");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 20, -1, -1));

        imgpath.setEditable(false);
        imgpath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imgpathActionPerformed(evt);
            }
        });
        jPanel1.add(imgpath, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, 100, -1));

        btnpilih.setText("Add Image");
        btnpilih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpilihActionPerformed(evt);
            }
        });
        jPanel1.add(btnpilih, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, -1));

        lbimage.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(lbimage, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 80, 80));
        jPanel1.add(tfaddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 240, 190, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnsignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsignupActionPerformed
        // TODO add your handling code here:
        edit();
        String inputUsername = tfnama.getText();
        mainpage mainpage = new mainpage();
        mainpage.setUsername(inputUsername);
        mainpage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsignupActionPerformed

    private void signinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signinMouseClicked
        // TODO add your handling code here:
        String inputUsername = tfnama.getText();
        mainpage mainpage = new mainpage();
        mainpage.setUsername(inputUsername);
        mainpage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_signinMouseClicked

    private void imgpathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imgpathActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_imgpathActionPerformed

    private void btnpilihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpilihActionPerformed
        // TODO add your handling code here:
        inputImage();
    }//GEN-LAST:event_btnpilihActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            UIManager.setLookAndFeel(new FlatLightLaf()); // You can also use FlatDarkLaf or other themes
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new userupdate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnpilih;
    private javax.swing.JButton btnsignup;
    private javax.swing.JTextField imgpath;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbimage;
    private javax.swing.JLabel signin;
    private javax.swing.JTextField tfaddress;
    private javax.swing.JTextField tfemail;
    private javax.swing.JTextField tfnama;
    private javax.swing.JTextField tfpass;
    // End of variables declaration//GEN-END:variables
}
