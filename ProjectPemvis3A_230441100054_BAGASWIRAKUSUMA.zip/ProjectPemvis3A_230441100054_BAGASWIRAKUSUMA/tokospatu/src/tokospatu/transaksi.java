/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tokospatu;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author LENOVO
 */
public class transaksi extends javax.swing.JFrame {

    /**
     * Creates new form transaksi
     */
    Connection conn;
    private String sepatu;
    private int idsepatu;
    private int idcust;
    private String namacust;
    public transaksi() {
        initComponents();
        conn = koneksi.getConnection();
        jumlah.setText("1");
        btnpayment();
        jumlah.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updatebayar();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updatebayar();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updatebayar();
            }
        });
    }
    
    public void setcust(String inputUsername){
        this.namacust = inputUsername;
         try {
        String cust = namacust;
        String userQuery = "SELECT * FROM customers WHERE namacust = ?";
        PreparedStatement psUser = conn.prepareStatement(userQuery);
        psUser.setString(1, cust);
        ResultSet rsUser = psUser.executeQuery();
                while (rsUser.next()) {
                    int idC = rsUser.getInt("idcust");
                    SwingUtilities.invokeLater(() -> {
                        idcust = idC;
                    });
                }
            
        
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
    }
    public void setsepatu(String namaSepatu) {
        this.sepatu = namaSepatu;
        lbsepatu.setText(sepatu);
        try {
            String namasepatu = sepatu;
            String userQuery = "SELECT * FROM stock WHERE namaSepatu = ?";
            PreparedStatement psUser = conn.prepareStatement(userQuery);
            psUser.setString(1, namasepatu);
            ResultSet rsUser = psUser.executeQuery();
                    while (rsUser.next()) {
                        String jenis = rsUser.getString("jenisSepatu");
                        String harga = rsUser.getString("hargaSepatu");
                        String desk = rsUser.getString("deskripsiSepatu");
                        int idS = rsUser.getInt("idSepatu");
                        byte[] imgBytes = rsUser.getBytes("gambarSepatu");
                        ImageIcon icon = new ImageIcon(imgBytes);
                        Image scaledImage = icon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
                        lbgambar.setIcon(new ImageIcon(scaledImage));
                        SwingUtilities.invokeLater(() -> {
                        lbjenis.setText(jenis);
                        lbharga.setText(harga);
                        lbdesk.setText(desk);
                        idsepatu = idS;
                    });

                    }


        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private void tambah() {                                       
    int currentJumlah;

    if (jumlah.getText().isEmpty()) {
        currentJumlah = 1;
    } else {
        currentJumlah = Integer.parseInt(jumlah.getText());
    }
    currentJumlah++;

    jumlah.setText(String.valueOf(currentJumlah));
}

private void kurang() {                                       
    int currentJumlah = Integer.parseInt(jumlah.getText());

    if (currentJumlah > 1) {
        currentJumlah--;
    }

    jumlah.setText(String.valueOf(currentJumlah));
}

 private void updatebayar() {
        String cashText = jumlah.getText();
        int totalHarga = 0; 
        totalHarga = Integer.parseInt(lbharga.getText());
        if (!cashText.isEmpty()) {
            try {
                int cash = Integer.parseInt(cashText);
                int kembalianValue = cash * totalHarga;
                total.setText(String.valueOf(kembalianValue));
            } catch (NumberFormatException e) {
                total.setText("0");
            }
        } else {
            total.setText("0");
        }
    }
 
 private void btnpayment(){
        payment.setBackground(Color.decode("#ff8040"));
        payment.setForeground(Color.white);
        payment.setPreferredSize(new Dimension(150, 20));
        payment.putClientProperty(FlatClientProperties.STYLE, "arc: 20");
 }
 
 private void updatedata() {
        try {
                String sql = "INSERT INTO transaksi (totalharga, ukuran, sepatu, idSepatu, idcustomer, namacust, pembayaran) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);

                ps.setString(1, total.getText());
                if(uk40.isSelected()){
                    ps.setString(2, uk40.getText());
                } else if(uk41.isSelected()){
                    ps.setString(2, uk41.getText());
                } else if(uk42.isSelected()){
                    ps.setString(2, uk42.getText());
                } else if(uk43.isSelected()){
                    ps.setString(2, uk43.getText());
                } else{
                    ps.setString(2, uk44.getText());
                } 
                ps.setString(3, lbsepatu.getText());
                ps.setInt(4, idsepatu);
                ps.setInt(5, idcust);
                ps.setString(6, namacust);
                ps.setString(7, (String) paymet.getSelectedItem());

                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Payment Done");
        } catch (SQLException e) {
                System.out.println("Error Save Data: " + e.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        groupsize = new javax.swing.ButtonGroup();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lbharga = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Jlabel = new javax.swing.JLabel();
        Jlabel1 = new javax.swing.JLabel();
        lbsepatu = new javax.swing.JLabel();
        lbgambar = new javax.swing.JLabel();
        lbjenis = new javax.swing.JLabel();
        Jlabel2 = new javax.swing.JLabel();
        lbdesk = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        uk44 = new javax.swing.JRadioButton();
        uk40 = new javax.swing.JRadioButton();
        uk41 = new javax.swing.JRadioButton();
        uk42 = new javax.swing.JRadioButton();
        uk43 = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        total = new javax.swing.JTextField();
        jumlah = new javax.swing.JTextField();
        minus = new javax.swing.JButton();
        plus = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        payment = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        paymet = new javax.swing.JComboBox<>();

        jButton1.setText("jButton1");

        jLabel6.setText("jLabel6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(436, 369));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbharga.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        lbharga.setText("sepatu");
        jPanel1.add(lbharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 140, -1));

        jLabel1.setFont(new java.awt.Font("HelveticaNowText Black", 0, 24)); // NOI18N
        jLabel1.setText("PAYMENT");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, -1, -1));

        Jlabel.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        Jlabel.setText("Price :");
        jPanel1.add(Jlabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, -1, -1));

        Jlabel1.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        Jlabel1.setText("Type :");
        jPanel1.add(Jlabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, -1, -1));

        lbsepatu.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        lbsepatu.setText("sepatu");
        jPanel1.add(lbsepatu, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 240, -1));

        lbgambar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(lbgambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 70, 70));

        lbjenis.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        lbjenis.setText("sepatu");
        jPanel1.add(lbjenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 240, -1));

        Jlabel2.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        Jlabel2.setText("Description :");
        jPanel1.add(Jlabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, -1, -1));

        lbdesk.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        lbdesk.setText("sepatu");
        jPanel1.add(lbdesk, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 230, -1));

        jLabel2.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel2.setText("Payment Method :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));

        groupsize.add(uk44);
        uk44.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        uk44.setText("44");
        jPanel1.add(uk44, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, -1, -1));

        groupsize.add(uk40);
        uk40.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        uk40.setText("40");
        uk40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uk40ActionPerformed(evt);
            }
        });
        jPanel1.add(uk40, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, -1, -1));

        groupsize.add(uk41);
        uk41.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        uk41.setText("41");
        jPanel1.add(uk41, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, -1, -1));

        groupsize.add(uk42);
        uk42.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        uk42.setText("42");
        jPanel1.add(uk42, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 150, -1, -1));

        groupsize.add(uk43);
        uk43.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        uk43.setText("43");
        jPanel1.add(uk43, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 150, -1, -1));

        jLabel5.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel5.setText("Size :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, -1, -1));

        total.setEditable(false);
        total.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalActionPerformed(evt);
            }
        });
        jPanel1.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 120, -1));

        jumlah.setEditable(false);
        jumlah.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jumlah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jumlahActionPerformed(evt);
            }
        });
        jPanel1.add(jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 190, 30, -1));

        minus.setText("-");
        minus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minusActionPerformed(evt);
            }
        });
        jPanel1.add(minus, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, 30, -1));

        plus.setText("+");
        plus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                plusActionPerformed(evt);
            }
        });
        jPanel1.add(plus, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 190, 30, -1));

        jLabel4.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel4.setText("Total :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        payment.setText("Confirm Payment");
        payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymentActionPerformed(evt);
            }
        });
        jPanel1.add(payment, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins Light", 0, 12)); // NOI18N
        jLabel7.setText("Shoes :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, -1, -1));

        paymet.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Oneline Payment", "Cash on Delivery" }));
        jPanel1.add(paymet, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, 210, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void uk40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uk40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uk40ActionPerformed

    private void totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalActionPerformed

    private void paymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymentActionPerformed
        // TODO add your handling code here:
        updatedata();
    }//GEN-LAST:event_paymentActionPerformed

    private void plusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_plusActionPerformed
        // TODO add your handling code here:
        tambah();
    }//GEN-LAST:event_plusActionPerformed

    private void minusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minusActionPerformed
        // TODO add your handling code here:
        kurang();
    }//GEN-LAST:event_minusActionPerformed

    private void jumlahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jumlahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jumlahActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            UIManager.setLookAndFeel(new FlatLightLaf()); // You can also use FlatDarkLaf or other themes
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Jlabel;
    private javax.swing.JLabel Jlabel1;
    private javax.swing.JLabel Jlabel2;
    private javax.swing.ButtonGroup groupsize;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jumlah;
    private javax.swing.JLabel lbdesk;
    private javax.swing.JLabel lbgambar;
    private javax.swing.JLabel lbharga;
    private javax.swing.JLabel lbjenis;
    private javax.swing.JLabel lbsepatu;
    private javax.swing.JButton minus;
    private javax.swing.JButton payment;
    private javax.swing.JComboBox<String> paymet;
    private javax.swing.JButton plus;
    private javax.swing.JTextField total;
    private javax.swing.JRadioButton uk40;
    private javax.swing.JRadioButton uk41;
    private javax.swing.JRadioButton uk42;
    private javax.swing.JRadioButton uk43;
    private javax.swing.JRadioButton uk44;
    // End of variables declaration//GEN-END:variables
}
